//
//  Constantes.swift
//  Game Of Matches
//
//  Created by Matthieu PASSEREL on 19/11/2017.
//  Copyright © 2017 Matthieu PASSEREL. All rights reserved.
//

import UIKit

func layerDe(vue: UIView) {
    vue.layer.cornerRadius = 25
    vue.layer.shadowColor = UIColor.darkGray.cgColor
    vue.layer.shadowRadius = 5
    vue.layer.shadowOffset = CGSize(width: 5, height: 5)
    vue.layer.shadowOpacity = 0.75
}
