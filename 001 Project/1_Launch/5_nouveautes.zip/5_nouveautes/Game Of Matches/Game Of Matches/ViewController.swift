//
//  ViewController.swift
//  Game Of Matches
//
//  Created by Matthieu PASSEREL on 15/11/2017.
//  Copyright © 2017 Matthieu PASSEREL. All rights reserved.
//

import UIKit

enum Attirance {
    case neutre
    case oui
    case non
}


class ViewController: UIViewController {

    var matchPossible: MatchPossibleVue!
    var frameDOrigine: CGRect?
    var matchSuivant: MatchPossibleVue?
    var matchVue: ItsAMatchVue?
    
    var personnages = ["Emilia", "Kit", "Iwan", "Natalie", "Sophie", "Peter"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        title = "Game Of Match"
        
        matchPossible = MatchPossibleVue(frame: CGRect(x: 20, y: 100, width: view.frame.width - 40, height: view.frame.height - 150))
        matchPossible.perso = personnageAleatoire()
        view.addSubview(matchPossible)
        
        
        NotificationCenter.default.addObserver(self, selector: #selector(changerDePerso), name: Notification.Name("Continuer"), object: nil)
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard bonneVue(touches: touches) else { return }
        frameDOrigine = matchPossible.frame
        matchSuivant = MatchPossibleVue(frame: frameDOrigine!)
        matchSuivant?.perso = personnageAleatoire()
        view.addSubview(matchSuivant!)
        view.sendSubview(toBack: matchSuivant!)
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard bonneVue(touches: touches) else { return }
        guard let position = touches.first?.location(in: self.view).x else { return }
        matchPossible.center.x = position
        
        //Rotation
        let distanceDuCentre = (self.view.frame.width / 2) - position
        let angleDeRotation = -distanceDuCentre / 360
        matchPossible.transform = CGAffineTransform(rotationAngle: angleDeRotation)
        //Voir si distanceduCentre est éloignée à droite ou à gauche
        if distanceDuCentre >= 150 {
            matchPossible.attr = .non
        } else if distanceDuCentre <= -150 {
            matchPossible.attr = .oui
        } else {
            matchPossible.attr = .neutre
        }
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard bonneVue(touches: touches) else { return }
        matchPossible.transform = CGAffineTransform.identity
        matchPossible.center.x = self.view.frame.width / 2
        if matchPossible.attr != .neutre {
            if matchPossible.attr == .oui && matchAleatoire() {
                //Montrer vue de match
                print("C'est un match")
                guard let frame = frameDOrigine else { return }
                matchVue = ItsAMatchVue(frame: frame)
                matchVue?.persoMatch = matchPossible.perso
                view.addSubview(matchVue!)
            } else {
                changerDePerso()
            }
        }
    }
    
    @objc func changerDePerso() {
        if matchVue != nil {
            matchVue?.removeFromSuperview()
            matchVue = nil
        }
        matchPossible.attr = .neutre
        guard matchSuivant != nil else { return }
        matchPossible.perso = matchSuivant?.perso
        matchSuivant?.removeFromSuperview()
        matchSuivant = nil
    }
    
    func bonneVue(touches: Set<UITouch>) -> Bool {
        if let touch = touches.first, touch.view == matchPossible.masque {
            return true
        } else {
            return false
        }
    }
    
    func matchAleatoire() -> Bool {
        return Int(arc4random_uniform(2)) == 0
    }
    
    func personnageAleatoire() -> String {
            return personnages[Int(arc4random_uniform(UInt32(personnages.count)))]
    }
    
    
    
    
    
    
    
}

