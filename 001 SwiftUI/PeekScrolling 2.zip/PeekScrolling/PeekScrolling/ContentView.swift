//
//  ContentView.swift
//  PeekScrolling
//
//  Created by Meng To on 2020-05-23.
//  Copyright © 2020 Meng To. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    @State var show = false
    
    var body: some View {
        ZStack {
            Color(#colorLiteral(red: 0.9490196078, green: 0.9647058824, blue: 1, alpha: 1)).edgesIgnoringSafeArea(.all)
            
            VStack {
                Text("Courses")
                    .font(.largeTitle).bold()
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.horizontal, 30)

                ZStack {
                    Image(uiImage: #imageLiteral(resourceName: "Content"))
                        .shadow(color: Color(#colorLiteral(red: 0.3176470696926117, green: 0.1568627506494522, blue: 0.7450980544090271, alpha: 0.20000000298023224)), radius:40, x:0, y:20)
                        .offset(x: show ? -20 : 0)
                        .rotation3DEffect(Angle(degrees: show ? 0 : 10), axis: (x: 0, y: 10, z: 0))
                        .animation(Animation.spring(response: 0.6, dampingFraction: 0.6, blendDuration: 0).delay(0.1))

                    Image(uiImage: #imageLiteral(resourceName: "Card1"))
                        .shadow(color: Color(#colorLiteral(red: 0.3647058904, green: 0.06666667014, blue: 0.9686274529, alpha: 1)).opacity(0.3), radius: show ? 100 : 40, x:0, y: show ? 100 : 20)
                        .offset(x: show ? -330 : 0)
                        .rotationEffect(Angle(degrees: show ? 10 : 0))
                        .animation(.spring(response: 0.6, dampingFraction: 0.6, blendDuration: 0))
                }
                .onTapGesture {
                    self.show.toggle()
                }

                Spacer()
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
